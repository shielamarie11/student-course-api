# Campus Connect — Screenshots

Drop your screenshots here before submitting the laboratory:

1. `01-dashboard.png` — the Campus Connect dashboard with the four summary cards.
2. `02-students.png` — the student list with the add-student form open.
3. `03-courses.png` — the course catalog.
4. `04-enrollment.png` — enrollment records with status badges.
5. `05-announcements.png` — announcements.
6. `06-api-console.png` — this Flask console showing "Connected to the Flask API".
7. `07-sqlite.png` — the students table viewed in DB Browser for SQLite.
