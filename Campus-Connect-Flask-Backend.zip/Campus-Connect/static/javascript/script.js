// Small diagnostic console for the Campus Connect REST API.
// Every page fetches its data from the Flask endpoints below.
const API = "/api";

async function getJSON(path) {
  const response = await fetch(API + path, { headers: { Accept: "application/json" } });
  if (!response.ok) throw new Error("Request failed with status " + response.status);
  return response.json();
}

function cell(text) {
  const td = document.createElement("td");
  td.textContent = text === undefined || text === null || text === "" ? "—" : text;
  return td;
}

function fillTable(name, rows, toCells) {
  const body = document.querySelector('[data-table="' + name + '"]');
  if (!body) return;
  body.innerHTML = "";
  if (!rows.length) {
    const tr = document.createElement("tr");
    const td = cell("No records yet.");
    td.colSpan = 6;
    tr.appendChild(td);
    body.appendChild(tr);
    return;
  }
  rows.forEach((row) => {
    const tr = document.createElement("tr");
    toCells(row).forEach((value) => {
      if (value instanceof Node) tr.appendChild(value);
      else tr.appendChild(cell(value));
    });
    body.appendChild(tr);
  });
}

async function loadIndex() {
  const status = document.getElementById("health");
  try {
    const health = await getJSON("/health");
    status.className = "status ok";
    status.textContent = "Connected to the Flask API — database: " + health.database + " (" + health.engine + ")";
  } catch (error) {
    status.className = "status bad";
    status.textContent = "The API is not reachable: " + error.message;
    return;
  }

  const [students, courses, enrollments, announcements] = await Promise.all([
    getJSON("/students"),
    getJSON("/courses"),
    getJSON("/enrollments"),
    getJSON("/announcements"),
  ]);

  const counts = { students, courses, enrollments, announcements };
  Object.keys(counts).forEach((key) => {
    const target = document.querySelector('[data-count="' + key + '"]');
    if (target) target.textContent = counts[key].length;
  });
}

async function loadStudents() {
  const rows = await getJSON("/students");
  fillTable("students", rows, (row) => [
    row.student_number,
    row.first_name + " " + row.last_name,
    row.program,
    row.year_level,
    row.email,
    row.contact_number,
  ]);
}

async function loadCourses() {
  const rows = await getJSON("/courses");
  fillTable("courses", rows, (row) => [row.course_code, row.course_name, row.department, row.capacity]);
}

async function loadEnrollments() {
  const rows = await getJSON("/enrollments");
  fillTable("enrollments", rows, (row) => {
    const badge = document.createElement("span");
    badge.className = "pill " + row.status;
    badge.textContent = row.status;
    return [
      row.id,
      row.student_number + " — " + row.student_name,
      row.course_code + " — " + row.course_name,
      row.enrollment_date,
      badge,
    ];
  });
}

async function loadAnnouncements() {
  const rows = await getJSON("/announcements");
  const list = document.getElementById("announcement-list");
  list.innerHTML = "";
  rows.forEach((row) => {
    const card = document.createElement("article");
    card.className = "notice";
    const title = document.createElement("h3");
    title.textContent = row.title;
    const body = document.createElement("p");
    body.textContent = row.content;
    const meta = document.createElement("small");
    meta.textContent = row.author + " · " + row.date_posted;
    card.append(title, body, meta);
    list.appendChild(card);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const page = document.body.dataset.page;
  const loaders = {
    index: loadIndex,
    students: loadStudents,
    courses: loadCourses,
    enrollment: loadEnrollments,
    announcements: loadAnnouncements,
  };
  const load = loaders[page];
  if (load) load().catch((error) => console.error(error));
});